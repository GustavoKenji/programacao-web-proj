module.exports = {
    mongoURL: 'mongodb+srv://Kenji:webproj2021@cluster0.74rxg.mongodb.net/test?authSource=admin&replicaSet=atlas-sngwiy-shard-0&readPreference=primary&appname=MongoDB%20Compass&ssl=true',
    //mongoURL: 'mongodb://127.0.0.1:27017',
    dbName: 'projeto3'
};
